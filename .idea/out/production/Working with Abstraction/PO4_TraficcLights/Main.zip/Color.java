package PO4_TraficcLights;

public enum Color {
    RED,
    GREEN,
    YELLOW

    //if red -> green
    //if green -> yellow
    // if yellow -> red
}
