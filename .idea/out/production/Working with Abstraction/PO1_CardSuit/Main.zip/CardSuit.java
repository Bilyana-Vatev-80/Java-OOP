package PO1_CardSuit;

public enum CardSuit {
    CLUBS, //спатия
    DIAMONDS, //каро
    HEARTS, // купа
    SPADES  // пика
}
